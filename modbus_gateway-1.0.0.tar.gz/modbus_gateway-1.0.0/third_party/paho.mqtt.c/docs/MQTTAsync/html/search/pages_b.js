var searchData=
[
  ['reconnect_0',['Automatic Reconnect',['../auto_reconnect.html',1,'']]]
];
