var searchData=
[
  ['vs_20synchronous_20client_20applications_0',['Asynchronous vs synchronous client applications',['../async.html',1,'']]]
];
