var searchData=
[
  ['quality_20of_20service_0',['Quality of service',['../qos.html',1,'']]]
];
